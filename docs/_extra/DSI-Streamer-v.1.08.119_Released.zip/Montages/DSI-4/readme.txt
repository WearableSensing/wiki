DSI-4_default0.mtg montage is backedup for a conventional DSI4.
DSI-4_default.mtg montage is set for the Oraigo (DSI4D) headband.